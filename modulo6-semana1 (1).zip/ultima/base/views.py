from django.shortcuts import render


# View inicio, que é a primeira a ser acessada pelo usuário
def inicio(request):
    return render(request, 'inicio.html')


# View contato
def contato(request):
    return render(request, 'contato.html')